package corejava;

public class p {
    public void AddProduct() {
        System.out.print("p");
    }
}
